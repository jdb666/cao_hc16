"""HC16 + gréement Rando (mâts extérieurs), sans coffre.
Lit cotes.yaml, construit l'assemblage CadQuery, exporte STEP.
Usage : python hc16_rando.py [cotes.yaml] [sortie.step]
"""
import math, sys, yaml
import cadquery as cq
from cadquery import Vector as V

def interp(tab, x):
    for (x0, y0), (x1, y1) in zip(tab, tab[1:]):
        if x <= x1:
            return y0 + (y1 - y0) * (x - x0) / (x1 - x0)
    return tab[-1][1]

def coque(c, yc):
    """Lissage de sections périodiques. Départ à x = 60 mm : en dessous, les sections trop
    fines rendent les booléens OCC instables (pointe d'étrave tronquée de 6 cm)."""
    L = c["longueur"]
    xs = [60, 120, 200, 300, 450, 600, 800, 1000, 1250, 1500, 1800, 2100, 2400,
          2800, 3200, 3600, 4000, 4400, 4700, L]
    wires = []
    for x in xs:
        k, b = interp(c["quille"], x), interp(c["demi_largeur"], x)
        d = interp(c["pont"], x) - c["bouge_pont"]       # livet ; le dessus du bombé = ligne de pont
        n = 12
        pts = [V(x, yc + b * math.cos(math.pi * j / n),
                 d - (d - k) * math.sin(math.pi * j / n) ** 0.55) for j in range(n + 1)]
        pts += [V(x, yc - b * math.cos(math.pi * j / n),
                  d + c["bouge_pont"] * math.sin(math.pi * j / n)) for j in range(1, n)]
        wires.append(cq.Wire.assembleEdges([cq.Edge.makeSpline(pts, periodic=True)]))
    return cq.Solid.makeLoft(wires, ruled=False)

def aire_cdg(p):
    a = cx = cz = 0.0
    for (x0, z0), (x1, z1) in zip(p, p[1:] + p[:1]):
        k = x0 * z1 - x1 * z0
        a += k; cx += (x0 + x1) * k; cz += (z0 + z1) * k
    return abs(a) / 2, (cx / (3 * a), cz / (3 * a))

def voile_restante(contour, quete, frac):
    """Enroulement vertical autour du guindant : chaque tranche perd la même largeur d
    (repère du mât), la chute avance de d, le haut dont la corde < d disparaît.
    frac = part de surface enroulée (0 = pleine, 1 = roulée). Retourne (points dx,dz, d)."""
    ca, sa = math.cos(quete), math.sin(quete)
    loc = [tuple(q) for q in contour]            # (u perp. mât vers l'arrière, w le long du mât)
    monde = lambda pts: [(u * ca + w * sa, -u * sa + w * ca) for u, w in pts]
    if frac <= 0:
        return monde(loc), 0.0
    if frac >= 1:
        return [], None
    def clip(d):
        out = []
        for a_, b_ in zip(loc, loc[1:] + loc[:1]):
            ia, ib = a_[0] >= d, b_[0] >= d
            if ia: out.append(a_)
            if ia != ib:
                t = (d - a_[0]) / (b_[0] - a_[0])
                out.append((d, a_[1] + t * (b_[1] - a_[1])))
        return [(u - d, w) for u, w in out]
    a0 = aire_cdg(loc)[0]; lo, hi = 0.0, max(u for u, _ in loc)
    for _ in range(60):
        d = (lo + hi) / 2
        lo, hi = (d, hi) if aire_cdg(clip(d))[0] > (1 - frac) * a0 else (lo, d)
    return monde(clip(d)), d

def cyl(p0, p1, d):
    p0, p1 = V(*p0), V(*p1)
    v = p1 - p0
    return cq.Solid.makeCylinder(d / 2, v.Length, p0, v.normalized())

def ellipsoide(ax, ay, az, centre):
    """Ellipsoïde plein (sphère unité déformée), centré en `centre`."""
    from OCP.gp import gp_GTrsf, gp_Mat, gp_XYZ
    from OCP.BRepBuilderAPI import BRepBuilderAPI_GTransform
    g = gp_GTrsf(); g.SetVectorialPart(gp_Mat(ax, 0, 0, 0, ay, 0, 0, 0, az))
    g.SetTranslationPart(gp_XYZ(*centre))
    # sphère complète ; couture tournée de 33° pour l'écarter du plan de coupe y = 0
    sph = cq.Solid.makeSphere(1, V(0, 0, 0), V(0, 0, 1), -90, 90, 360).rotate(V(0, 0, 0), V(0, 0, 1), 33)
    return cq.Solid(BRepBuilderAPI_GTransform(sph.wrapped, g, True).Shape())

def section_coffre(xa, zb, zt, xp, ep_ar=0.0, ep_f=0.0, ep_t=0.0, ep_b=0.0, n=24, zcut=None):
    """Section (plan XZ) : face arrière verticale en xa, plateau horizontal en haut (zt) de xa
    jusqu'à xp, puis quart de rond de rayon R = zt - zb centré en (xp, zb) jusqu'au fond (zb).
    Les ep_* décalent vers l'intérieur (face AR, fond, plateau, bordé)."""
    R = zt - zb
    r = R - ep_b
    zh = zt if zcut is None else min(zt, zcut)                # coupe par un plan horizontal
    xr, zbi, zti = xa - ep_ar, zb + ep_f, zh - ep_t
    t0 = math.asin(min(1.0, (zti - zb) / r))                 # départ de l'arc sous le plateau
    t1 = math.asin(min(1.0, (zbi - zb) / r))                 # arrivée de l'arc au-dessus du fond
    arc = [(xp - r * math.cos(t), zb + r * math.sin(t)) for t in [t0 + (t1 - t0) * i / n for i in range(n + 1)]]
    return dict(pts=[(xr, zbi), (xr, zti)] + arc)

def solide_section(sec, y0, larg):
    """Extrude la section (polyligne dense) entre y0 et y0 - larg (vers -Y)."""
    return cq.Workplane("XZ", origin=(0, y0, 0)).polyline(sec["pts"]).close().extrude(larg).val()

def profil_coffre(xa, zb, zpl, xp, Rb, x_top, zcol, n=40):
    """Profil extérieur (plan XZ) : fond, quart de rond R=Rb centré (xp, zb) jusqu'au niveau du plateau,
    puis arc d'ellipse raccordé en tangence (C1) jusqu'à (x_top, zcol) à tangente horizontale,
    dessus plat jusqu'à la face arrière xa. Retourne (points, infos)."""
    dz = zpl - zb
    x1 = xp - math.sqrt(Rb * Rb - dz * dz)
    slope = (xp - x1) / dz
    dx, H = x_top - x1, zcol - zpl
    f = lambda B: (B * B * dx) / ((dx * dx / (1 - ((B - H) / B) ** 2)) * (B - H)) - slope
    lo, hi = H * 1.0001, 80 * H
    for _ in range(200):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if f(lo) * f(mid) <= 0 else (mid, hi)
    B = (lo + hi) / 2
    A_ = math.sqrt(dx * dx / (1 - ((B - H) / B) ** 2))
    ze = zcol - B
    t0 = math.asin(max(-1.0, min(1.0, (zpl - ze) / B)))
    pts = [(xa, zb), (xp - Rb, zb)]
    tc = math.asin(dz / Rb)
    pts += [(xp - Rb * math.cos(t), zb + Rb * math.sin(t)) for t in [tc * i / n for i in range(1, n + 1)]]
    pts += [(x_top - A_ * math.cos(t), ze + B * math.sin(t)) for t in [t0 + (math.pi / 2 - t0) * i / n for i in range(1, n + 1)]]
    pts += [(xa, zcol)]
    return pts, dict(x1=x1, A=A_, B=B, ze=ze, avant=xp - Rb)

def coffre(A, k):
    """Coffre (CP cousu-collé) devant la poutre AV. Joues « ellipsoïdales » : deux quarts d'ellipse de même
    hauteur, tangents à l'horizontale au collier ; extrémités = pointe avant du coffre, collier, bout
    arrière du banc. Le coffre suit le quart d'ellipse avant jusqu'à la hauteur du collier puis reste plat
    jusqu'à la poutre ; plateau intérieur. Moteur : chaise centrée sous le coffre, bascule vers l'arrière
    dans l'axe du bateau, sous la martingale (arbre enfoncé à fond avant de basculer)."""
    from shapely.geometry import Polygon
    m = CFG_MAT
    qa = math.radians(m["quete_deg"])
    zc = m["z_pied"] + m["collier_hauteur"] * math.cos(qa)
    W, xa, zb = k["largeur"], k["face_ar_x"], k["fond_z"]
    ztop = k.get("dessus_z") or (zc + k["dessus_au_dessus_collier"])
    xcol = m["x_pied"] + m["collier_hauteur"] * math.sin(qa)
    xf = k["avant_x"]
    b = k["bancs"]
    xr = xa + b["longueur"]
    af, ar_, bj = xcol - xf, xr - xcol, ztop - zb
    e, ef, ec = k["ep_bordé"], k["ep_flasque"], k["ep_cloison"]
    bois = cq.Color(0.80, 0.58, 0.38)
    # fond en V transversal, parallèle aux câbles de martingale : zb au milieu, zb_s au droit des joues
    wi = W / 2 - ef
    zb_s = k.get("fond_z_cotes", zb)
    cpl = k.get("fond_plat_demi", 0.0)      # fond polygonal : plat sur |y| <= cpl, puis pente jusqu'aux joues
    zb_at = lambda y: zb + (zb_s - zb) * max(0.0, min(1.0, (abs(y) - cpl) / (wi - cpl)))
    def profil(zb_, off=0.0, n=48):
        a_, h_ = af - off, ztop - zb_ - 2 * off
        pts_ = [(xa - off, zb_ + off)]
        pts_ += [(xcol - a_ * math.cos(t), zb_ + off + h_ * math.sin(t)) for t in [math.pi / 2 * i / n for i in range(n + 1)]]
        return pts_ + [(xa - off, ztop - off)]
    def loft(off, y_ext):
        solids = []
        for sg in (1, -1):
            ys_ = [0.0] + ([cpl] if cpl > 0 else []) + [y_ext]
            wires = [cq.Wire.makePolygon([V(x, sg * yy, z) for x, z in profil(zb_at(min(yy, wi)) if yy <= wi else zb_s, off)], close=True) for yy in ys_]
            solids.append(cq.Solid.makeLoft(wires, True))
        return solids[0].fuse(solids[1]).clean()
    avant = [(xcol - af * math.cos(t), zb + bj * math.sin(t)) for t in [math.pi / 2 * i / 48 for i in range(49)]]
    pts = [(xa, zb)] + avant + [(xa, ztop)]
    inner = Polygon(pts).buffer(-e, join_style=2)
    ipts = list(inner.exterior.coords)[:-1]
    ext_s = loft(0.0, wi)
    int_s = loft(e, wi + 1)
    coque = ext_s.cut(int_s)
    zpl = k["plateau_z"]
    plat = None
    if zpl < ztop - 60:
        plat = cq.Solid.makeBox(xa - xf, 2 * wi, k["ep_plateau"], V(xf, -wi, zpl - k["ep_plateau"])).intersect(int_s)
    mo = k.get("moteur")
    niche_ext = None
    if mo and mo.get("mode") == "transversal":
        tv = mo["transversal"]; fe = tv["fente"]
        fente = cq.Solid.makeBox(fe["x1"] - fe["x0"], fe["y1"] - fe["y0"], zb_s - zb + 120, V(fe["x0"], fe["y0"], zb - 60))
        volet = coque.intersect(fente)
        coque = coque.cut(fente)
        if tv.get("volet", True):
            # volet fermé : le fond découpé, moins une encoche autour de l'arbre en marche
            enc = cq.Solid.makeBox(fe["x1"] - fe["x0"] + 20, tv["encoche_arbre"], 200, V(fe["x0"] - 10, fe["y0"] - 10, zb - 100))
            A.add(volet.cut(enc), name="fond_volet", color=cq.Color(0.86, 0.66, 0.44))
    elif mo and mo.get("mode") == "arriere":
        nn = mo["arriere"]["niche"]; ym = mo["arriere"]["y"]; en = nn["ep"]
        niche_ext = cq.Solid.makeBox(nn["x1"] - nn["x0"] + 2 * en, 2 * nn["demi_y"] + 2 * en, nn["z_haut"] + en - zb + 20,
                                     V(nn["x0"] - en, ym - nn["demi_y"] - en, zb - 20))
        niche_int = cq.Solid.makeBox(nn["x1"] - nn["x0"], 2 * nn["demi_y"], nn["z_haut"] - zb + 40, V(nn["x0"], ym - nn["demi_y"], zb - 40))
        coque = coque.cut(niche_int)
        plat = plat.cut(niche_ext) if plat is not None else None
        niche = niche_ext.cut(niche_int).cut(cq.Solid.makeBox(4000, 4000, 1000, V(-1000, -2000, zb - 1000 + e))).intersect(int_s)
        A.add(niche, name="moteur_niche", color=cq.Color(0.70, 0.49, 0.30))
    elif mo and mo.get("mode") == "avant" and "boite" in mo["avant"]:
        bo = mo["avant"]["boite"]
        ep_p = bo["ep"]
        # boîte étroite au milieu du coffre : fente ouverte en dessous et dans la face avant (jusqu'à z_fente)
        niche_ext = cq.Solid.makeBox(xa - xf + 50, 2 * bo["demi_y"] + 2 * ep_p, 1500, V(xf - 50, -bo["demi_y"] - ep_p, zb - 200))
        niche_ext = niche_ext.cut(cq.Solid.makeBox(xa - bo["x_ar"], 2 * bo["demi_y"] + 2 * ep_p, 1500, V(bo["x_ar"] + ep_p, -bo["demi_y"] - ep_p, zb - 200)))
        vide = cq.Solid.makeBox(bo["x_ar"] - xf + 50, 2 * bo["demi_y"], 1500, V(xf - 50, -bo["demi_y"], zb - 200))
        coque = coque.cut(vide)
        plat = plat.cut(niche_ext) if plat is not None else None
        parois = niche_ext.cut(vide).intersect(ext_s)
        # face avant de la boîte au-dessus de la fente (ferme la boîte devant, au-dessus de z_fente)
        av_pts = [(x, z) for x, z in avant if z >= bo["z_fente"]]
        if av_pts:
            fb = cq.Workplane("XZ", origin=(0, bo["demi_y"], 0)).polyline([(xa, bo["z_fente"])] + [(x, z) for x, z in avant if z >= bo["z_fente"]] + [(xa, ztop)]).close().extrude(2 * bo["demi_y"]).val()
            peau = fb.cut(cq.Workplane("XZ", origin=(0, bo["demi_y"] + 1, 0)).polyline(
                [(xa, bo["z_fente"])] + [(x, z) for x, z in list(inner.exterior.coords) if z >= bo["z_fente"] and x < xa - 1] + [(xa, ztop - e)]).close().extrude(2 * bo["demi_y"] + 2).val())
            if bo.get("face_fermee", False):
                A.add(peau, name="moteur_boite_face", color=cq.Color(0.70, 0.49, 0.30))
        A.add(parois, name="moteur_boite", color=cq.Color(0.70, 0.49, 0.30))
    elif mo and mo.get("mode", "vertical") == "vertical":
        pu = mo["puits"]
        ep_p = pu["ep"]
        # boîte verticale traversant le coffre : passage de l'arbre et de la tête au relevage
        niche_ext = cq.Solid.makeBox(pu["x1"] - pu["x0"] + 2 * ep_p, 2 * pu["demi_y"] + 2 * ep_p, 1500,
                                     V(pu["x0"] - ep_p, -pu["demi_y"] - ep_p, zb - 200))
        niche_int = cq.Solid.makeBox(pu["x1"] - pu["x0"], 2 * pu["demi_y"], 1500, V(pu["x0"], -pu["demi_y"], zb - 200))
        coque = coque.cut(niche_ext)
        plat = plat.cut(niche_ext) if plat is not None else None
        puits = niche_ext.cut(niche_int).intersect(ext_s)
        A.add(puits, name="moteur_puits", color=cq.Color(0.70, 0.49, 0.30))
    tr_ = k.get("trappe")
    if tr_:
        blk = cq.Solid.makeBox(tr_["x1"] - tr_["x0"], tr_["y1"] - tr_["y0"], 400, V(tr_["x0"], tr_["y0"], ztop - 250))
        A.add(coque.intersect(blk), name="coffre_capot", color=cq.Color(0.86, 0.66, 0.44))
        coque = coque.cut(blk)
    A.add(coque, name="coffre_coque", color=bois)
    if plat is not None:
        A.add(plat, name="coffre_plateau", color=bois)
    if k.get("cloisons_y"):
        ycs = list(k["cloisons_y"])
    else:
        n = max(0, math.ceil(2 * wi / k["pas_cloisons"]) - 1)
        ycs = [-wi + 2 * wi * i / (n + 1) for i in range(1, n + 1)]
    for i, yc in enumerate(ycs, 1):
        cl = cq.Workplane("XZ", origin=(0, yc + ec / 2, 0)).polyline(profil(zb_at(yc), e)).close().extrude(ec).val()
        if niche_ext is not None:
            cl = cl.cut(niche_ext)
        if cl.Volume() > 1:
            A.add(cl, name=f"coffre_cloison_{i}", color=bois)
    k["_geom"] = dict(zt=ztop, xcol=xcol, avant=xf, arriere=xr, af=af, ar=ar_, b=bj, volume_L=ext_s.Volume() / 1e6, fond_cotes=zb_s)
    # pattes verticales de collier : sur la face extérieure des joues, devant et derrière le mât, jusqu'au collier
    pc = k.get("pattes_collier")
    if pc:
        alu = cq.Color(0.72, 0.74, 0.77)
        z0p, z1p = ztop - pc["recouvrement"], zc + pc["au_dessus_axe_collier"]
        for nom, sg in (("babord", 1), ("tribord", -1)):
            y0p = W / 2 if sg > 0 else -W / 2 - pc["ep"]
            for cote, x0p in (("av", xcol - pc["ecart"] - pc["larg"]), ("ar", xcol + pc["ecart"])):
                A.add(cq.Solid.makeBox(pc["larg"], pc["ep"], z1p - z0p, V(x0p, y0p, z0p)), name=f"patte_collier_{nom}_{cote}", color=alu)
    # joues : quart d'ellipse avant + quart d'ellipse arrière (dossier jusqu'au bout du banc)
    bj_s = ztop - zb_s
    avant_j = [(xcol - af * math.cos(t), zb_s + bj_s * math.sin(t)) for t in [math.pi / 2 * i / 48 for i in range(49)]]
    arriere = [(xcol + ar_ * math.sin(t), zb_s + bj_s * math.cos(t)) for t in [math.pi / 2 * i / 48 for i in range(1, 49)]]
    prof = avant_j + arriere
    for nom, y0 in (("babord", W / 2), ("tribord", -wi)):
        fl = cq.Workplane("XZ", origin=(0, y0, 0)).polyline(prof).close().extrude(ef).val()
        if POUTRE_AV.get("degagement") is not None:
            fl = fl.cut(POUTRE_AV["degagement"])
        else:
            fl = fl.cut(cq.Solid.makeCylinder(b["encoche_poutre_r"], ef + 20, V(b["poutre_x"], y0 + 10, b["poutre_z"]), V(0, -1, 0)))
        A.add(fl, name=f"joue_{nom}", color=cq.Color(0.74, 0.52, 0.34))
    zt0, L, hb = b["plan_z"], b["longueur"], b["hauteur"]
    zs = zt0 + hb
    # martingale : pilier sous le milieu de la poutre AV + deux câbles vers les pylônes (relevée sur photos)
    mg = k.get("martingale")
    if mg:
        gm = cq.Color(0.55, 0.55, 0.58)
        pa = POUTRE_AV or dict(x=mg["x"], z_ext=b["poutre_z"], fleche=0, r=38)
        xm_ = pa["x"]
        z_haut = pa["z_ext"] + pa["fleche"] - pa["r"]
        z_bas = pa["z_ext"] - mg["pied_sous_axe_extremites"]
        mg["_z_bas"] = z_bas
        top = V(xm_, 0, z_haut); bas = V(xm_, 0, z_bas)
        A.add(cq.Solid.makeCylinder(12, (top - bas).Length, bas, (top - bas).normalized()), name="martingale_pilier", color=gm)
        for nom, sg in (("babord", 1), ("tribord", -1)):
            ext_ = V(xm_, sg * mg["y_cable"], pa["z_ext"] - mg["cable_sous_axe_extremites"])
            A.add(cq.Solid.makeCylinder(3, (ext_ - bas).Length, bas, (ext_ - bas).normalized()), name=f"martingale_cable_{nom}", color=gm)
    # moteur, mode "arriere" : chaise pivotante fixée au fond du coffre (charnière transversale) ;
    # le moteur reste serré à 0° sur sa planche, c'est la chaise entière qui bascule vers l'arrière sous la martingale
    if mo and mo.get("mode") == "transversal":
        # moteur centré ; chaise pivotante : charnière longitudinale (axe x) dans le coffre, décalée côté tête ;
        # relevé : moteur couché en travers dans le coffre, au-dessus du fond (fente fermée par le volet)
        tv = mo["transversal"]
        brun = cq.Color(0.55, 0.36, 0.20); acier = cq.Color(0.6, 0.6, 0.62)
        xs_, e_h, zh = tv["x_arbre"], tv["charniere_decalage"], tv["charniere_z"]
        yh = -e_h
        ang = tv.get("bascule", 0)
        # fixe : deux paliers sur le fond, côté tête
        for nom, xp in (("av", tv["palier_av_x"]), ("ar", tv["palier_ar_x"])):
            zf = zb_at(yh) + e
            A.add(cq.Solid.makeBox(30, 40, zh + 15 - zf, V(xp - 15, yh - 20, zf)), name=f"charniere_palier_{nom}", color=acier)
        A.add(cq.Solid.makeCylinder(8, tv["palier_ar_x"] - tv["palier_av_x"] + 40, V(tv["palier_av_x"] - 20, yh, zh), V(1, 0, 0)), name="charniere_axe", color=acier)
        # mobile : planche de serrage, flasque porte-palier, moteur
        xpl1 = xs_ - mo["recul_arbre"]
        zpl1 = zh - tv["bride_sous_charniere"]
        zsb = zh + tv["arbre_au_dessus"] - mo["arbre_l"]
        zn = zsb - mo["nacelle_d"] / 2
        gris = cq.Color(0.25, 0.25, 0.27)
        parts = {
            "chaise_planche": cq.Solid.makeBox(tv["planche_ep"], 2 * tv["planche_demi_larg"], tv["planche_h"],
                                               V(xpl1 - tv["planche_ep"], -tv["planche_demi_larg"], zpl1 - tv["planche_h"])),
            "chaise_flasque": cq.Solid.makeBox(tv["flasque_ep"], tv["planche_demi_larg"] + e_h + 25, zh + 25 - (zpl1 - tv["planche_h"]),
                                               V(xpl1 - tv["planche_ep"] - tv["flasque_ep"], yh - 25, zpl1 - tv["planche_h"])),
            "chaise_bras": cq.Solid.makeBox(xpl1 - tv["planche_ep"] - tv["flasque_ep"] - tv["palier_av_x"] + 15, 30, 40,
                                            V(tv["palier_av_x"] + 15, yh - 15, zh - 20)),
            "moteur_arbre": cq.Solid.makeCylinder(mo["arbre_d"] / 2, mo["arbre_l"], V(xs_, 0, zsb)),
            "moteur_tete": cq.Solid.makeBox(mo["tete"][0], mo["tete"][1], mo["tete"][2], V(xs_ - mo["tete"][0] / 2, -mo["tete"][1] / 2, zsb + mo["arbre_l"])),
            "moteur_nacelle": cq.Solid.makeCylinder(mo["nacelle_d"] / 2, mo["nacelle_l"], V(xs_ - mo["nacelle_l"] / 2, 0, zn), V(1, 0, 0)),
            "moteur_helice": cq.Solid.makeCylinder(mo["helice_d"] / 2, 25, V(xs_ + mo["nacelle_l"] / 2 + 5, 0, zn), V(1, 0, 0)),
        }
        for nm, sh in parts.items():
            if ang:
                sh = sh.rotate(V(0, yh, zh), V(1, yh, zh), ang)
            col = (cq.Color(0.1, 0.1, 0.1) if nm == "moteur_helice" else gris) if nm.startswith("moteur") else brun
            A.add(sh, name=nm, color=col)
        k["_moteur"] = dict(helice_z=zn, bas_pale=zn - mo["helice_d"] / 2, tete_haut=zsb + mo["arbre_l"] + mo["tete"][2], x_arbre=xs_)
    elif mo and mo.get("mode") == "arriere" and mo["arriere"].get("type_chaise") == "fixe":
        # chaise fixe : planche de serrage suspendue sous le coffre ; le moteur bascule sur l'axe de sa propre bride
        ar = mo["arriere"]
        brun = cq.Color(0.55, 0.36, 0.20)
        xs_, ym = ar["x_arbre"], ar["y"]
        xp_, zp_ = xs_ - ar["bride_axe_devant_arbre"], ar["bride_axe_z"]
        xb1 = xp_ - ar["bride_axe_derriere_planche"]                    # face arrière de la planche
        zc_ = zp_ - ar["bride_axe_sur_planche"]                         # bord haut de la planche
        ang = ar.get("bascule", 0)
        A.add(cq.Solid.makeBox(ar["planche_ep"], 2 * ar["demi_larg"], ar["planche_h"], V(xb1 - ar["planche_ep"], ym - ar["demi_larg"], zc_ - ar["planche_h"])),
              name="chaise_planche", color=brun)
        zbas = zc_ - ar["planche_h"]
        car = ar.get("carter")
        x_av = car["x_av"] if car else xb1 - ar["long_joue"]
        for nom, sg in (("babord", 1), ("tribord", -1)):
            y0c = ym + ar["demi_passage"] if sg > 0 else ym - ar["demi_passage"] - ar["ep_joue"]
            zloc = min(zb_at(y0c), zb_at(y0c + ar["ep_joue"]))
            A.add(cq.Solid.makeBox(xb1 - x_av, ar["ep_joue"], zloc - zbas, V(x_av, y0c, zbas)),
                  name=f"chaise_joue_{nom}", color=brun)
        if car:
            # carter : fond et face avant entre les joues ; la tête relevée y est enfermée
            yl = ar["demi_passage"]
            zloc = min(zb_at(ym - yl), zb_at(ym + yl))
            A.add(cq.Solid.makeBox(xb1 - ar["planche_ep"] - x_av, 2 * yl, car["ep"], V(x_av, ym - yl, zbas)), name="carter_fond", color=brun)
            A.add(cq.Solid.makeBox(car["ep"], 2 * yl, zloc - zbas - car["ep"], V(x_av, ym - yl, zbas + car["ep"])), name="carter_face_av", color=brun)
        zsb = zp_ + ar["arbre_au_dessus"] - mo["arbre_l"]
        zn = zsb - mo["nacelle_d"] / 2
        gris = cq.Color(0.25, 0.25, 0.27)
        parts = {
            "moteur_arbre": cq.Solid.makeCylinder(mo["arbre_d"] / 2, mo["arbre_l"], V(xs_, ym, zsb)),
            "moteur_tete": cq.Solid.makeBox(mo["tete"][0], mo["tete"][1], mo["tete"][2], V(xs_ - mo["tete"][0] / 2, ym - mo["tete"][1] / 2, zsb + mo["arbre_l"])),
            "moteur_nacelle": cq.Solid.makeCylinder(mo["nacelle_d"] / 2, mo["nacelle_l"], V(xs_ - mo["nacelle_l"] / 2, ym, zn), V(1, 0, 0)),
            "moteur_helice": cq.Solid.makeCylinder(mo["helice_d"] / 2, 25, V(xs_ + mo["nacelle_l"] / 2 + 5, ym, zn), V(1, 0, 0)),
            "moteur_bride": cq.Solid.makeBox(ar["bride_axe_derriere_planche"] + 30, 80, 90, V(xb1, ym - 40, zc_ - 50)),
        }
        for nm, sh in parts.items():
            if ang and nm != "moteur_bride":
                sh = sh.rotate(V(xs_, ym, 0), V(xs_, ym, 1), ar["rotation_tete_avant_bascule"])   # barre tournée : nacelle en travers
                sh = sh.rotate(V(xp_, ym, zp_), V(xp_, ym + 1, zp_), -ang)                      # bascule sur l'axe de la bride
            A.add(sh, name=nm, color=(cq.Color(0.1, 0.1, 0.1) if nm == "moteur_helice" else gris))
        k["_moteur"] = dict(helice_z=zn, bas_pale=zn - mo["helice_d"] / 2, tete_haut=zsb + mo["arbre_l"] + mo["tete"][2], x_arbre=xs_,
                            planche=(zc_ - ar["planche_h"], zc_))
    elif mo and mo.get("mode") == "arriere":
        ar = mo["arriere"]
        brun = cq.Color(0.55, 0.36, 0.20); acier = cq.Color(0.6, 0.6, 0.62)
        xs_, ym = ar["x_arbre"], ar["y"]
        xh, zh = xs_ + ar["charniere_derriere_arbre"], ar["charniere_z"]
        ang = ar.get("bascule", 0)
        # pièces fixes : deux ferrures de charnière sous le fond du coffre + axe
        for nom, sg in (("babord", 1), ("tribord", -1)):
            y0c = ym + ar["demi_passage"] if sg > 0 else ym - ar["demi_passage"] - ar["ep_ferrure"]
            A.add(cq.Solid.makeBox(ar["long_ferrure"], ar["ep_ferrure"], zb - (zh - 25), V(xh - ar["long_ferrure"] / 2, y0c, zh - 25)),
                  name=f"charniere_ferrure_{nom}", color=acier)
        A.add(cq.Solid.makeCylinder(8, 2 * ar["demi_passage"] + 2 * ar["ep_ferrure"], V(xh, ym - ar["demi_passage"] - ar["ep_ferrure"], zh), V(0, 1, 0)),
              name="charniere_axe", color=acier)
        # pièces mobiles : planche de serrage (bord haut au niveau du fond du coffre) + moteur
        xb1 = xs_ - mo["recul_arbre"]
        zc_ = ar["bride_z"]
        dessus = ar["arbre_au_dessus"] if ang == 0 else ar["arbre_au_dessus_bascule"]
        zsb = zc_ + dessus - mo["arbre_l"]
        zn = zsb - mo["nacelle_d"] / 2
        gris = cq.Color(0.25, 0.25, 0.27)
        parts = {
            "chaise_planche": cq.Solid.makeBox(ar["planche_ep"], 2 * ar["demi_larg"], ar["planche_h"],
                                               V(xb1 - ar["planche_ep"], ym - ar["demi_larg"], zc_ - ar["planche_h"])),
            "chaise_bras_babord": cq.Solid.makeBox(xh - (xb1 - ar["planche_ep"]) + 15, 12, 36, V(xb1 - ar["planche_ep"], ym + ar["demi_larg"] - 12, zh - 18)),
            "chaise_bras_tribord": cq.Solid.makeBox(xh - (xb1 - ar["planche_ep"]) + 15, 12, 36, V(xb1 - ar["planche_ep"], ym - ar["demi_larg"], zh - 18)),
            "moteur_arbre": cq.Solid.makeCylinder(mo["arbre_d"] / 2, mo["arbre_l"], V(xs_, ym, zsb)),
            "moteur_tete": cq.Solid.makeBox(mo["tete"][0], mo["tete"][1], mo["tete"][2], V(xs_ - mo["tete"][0] / 2, ym - mo["tete"][1] / 2, zsb + mo["arbre_l"])),
            "moteur_nacelle": cq.Solid.makeCylinder(mo["nacelle_d"] / 2, mo["nacelle_l"], V(xs_ - mo["nacelle_l"] / 2, ym, zn), V(1, 0, 0)),
            "moteur_helice": cq.Solid.makeCylinder(mo["helice_d"] / 2, 25, V(xs_ + mo["nacelle_l"] / 2 + 5, ym, zn), V(1, 0, 0)),
        }
        for nm, sh in parts.items():
            if ang:
                if nm.startswith("moteur"):
                    sh = sh.rotate(V(xs_, ym, 0), V(xs_, ym, 1), ar["rotation_tete_avant_bascule"])
                sh = sh.rotate(V(xh, ym, zh), V(xh, ym + 1, zh), -ang)
            col = (cq.Color(0.1, 0.1, 0.1) if nm == "moteur_helice" else gris) if nm.startswith("moteur") else brun
            A.add(sh, name=nm, color=col)
        k["_moteur"] = dict(helice_z=zn, bas_pale=zn - mo["helice_d"] / 2, tete_haut=zsb + mo["arbre_l"] + mo["tete"][2], x_arbre=xs_)
    # moteur, mode "avant" : moteur reculé et rehaussé dans une boîte du coffre, bascule vers l'avant par la fente
    elif mo and mo.get("mode") == "avant":
        av = mo["avant"]
        brun = cq.Color(0.55, 0.36, 0.20)
        xs_ = av["x_arbre"]
        zpv = av["pivot_z"]
        xb0 = xs_ + mo["recul_arbre"]
        A.add(cq.Solid.makeBox(av["tableau_ep"], 2 * av["demi_larg"], av["tableau_haut"] - av["tableau_bas"],
                               V(xb0, -av["demi_larg"], av["tableau_bas"])), name="chaise_tableau", color=brun)
        for nom, sg in (("babord", 1), ("tribord", -1)):
            y0c = av["demi_larg"] if sg > 0 else -av["demi_larg"] - av["ep_joue"]
            A.add(cq.Solid.makeBox(av["tableau_ep"] + av["long_joue"], av["ep_joue"], zb - av["tableau_bas"],
                                   V(xb0, y0c, av["tableau_bas"])), name=f"chaise_joue_{nom}", color=brun)
        zn = zpv - mo["bride_nacelle_max"]
        zsb = zn + mo["nacelle_d"] / 2
        gris = cq.Color(0.25, 0.25, 0.27)
        nac = cq.Solid.makeCylinder(mo["nacelle_d"] / 2, mo["nacelle_l"], V(xs_ - mo["nacelle_l"] / 2, 0, zn), V(1, 0, 0))
        hel = cq.Solid.makeCylinder(mo["helice_d"] / 2, 25, V(xs_ + mo["nacelle_l"] / 2 + 5, 0, zn), V(1, 0, 0))
        rot = av.get("rotation_tete", 180)
        nac = nac.rotate(V(xs_, 0, 0), V(xs_, 0, 1), rot); hel = hel.rotate(V(xs_, 0, 0), V(xs_, 0, 1), rot)
        dessus = av.get("arbre_au_dessus", 50)
        parts = {
            "moteur_arbre": cq.Solid.makeCylinder(mo["arbre_d"] / 2, mo["arbre_l"], V(xs_, 0, zsb)),
            "moteur_tete": cq.Solid.makeBox(mo["tete"][0], mo["tete"][1], mo["tete"][2], V(xs_ - mo["tete"][0] / 2, -mo["tete"][1] / 2, zsb + mo["arbre_l"])),
            "moteur_nacelle": nac, "moteur_helice": hel,
        }
        ang = av.get("bascule", 0)
        for nm, sh in parts.items():
            if ang:
                sh = sh.rotate(V(xs_, 0, zpv), V(xs_, 1, zpv), ang)
            A.add(sh, name=nm, color=(cq.Color(0.1, 0.1, 0.1) if nm == "moteur_helice" else gris))
        k["_moteur"] = dict(helice_z=zn, bas_pale=zn - mo["helice_d"] / 2, tete_haut=zsb + mo["arbre_l"] + mo["tete"][2], x_arbre=xs_)
    # moteur : chaise centrée fixe (tableau sous le fond du coffre), relevage vertical par coulissement de l'arbre
    elif mo:
        ch = mo["chaise"]
        brun = cq.Color(0.55, 0.36, 0.20)
        xs_ = ch["x_face_ar"] + mo["recul_arbre"]
        A.add(cq.Solid.makeBox(ch["ep"], 2 * ch["demi_larg"], ch["z_bride"] - ch["z_bas"],
                               V(ch["x_face_ar"] - ch["ep"], -ch["demi_larg"], ch["z_bas"])), name="chaise_moteur", color=brun)
        z_nac = ch["z_bride"] - mo["bride_nacelle_max"] + mo.get("levee", 0)       # axe de la nacelle
        zsb = z_nac + mo["nacelle_d"] / 2
        gris = cq.Color(0.25, 0.25, 0.27)
        A.add(cq.Solid.makeCylinder(mo["arbre_d"] / 2, mo["arbre_l"], V(xs_, 0, zsb)), name="moteur_arbre", color=gris)
        A.add(cq.Solid.makeBox(mo["tete"][0], mo["tete"][1], mo["tete"][2], V(xs_ - mo["tete"][0] / 2, -mo["tete"][1] / 2, zsb + mo["arbre_l"])),
              name="moteur_tete", color=gris)
        A.add(cq.Solid.makeCylinder(mo["nacelle_d"] / 2, mo["nacelle_l"], V(xs_ - mo["nacelle_l"] / 2, 0, z_nac), V(1, 0, 0)),
              name="moteur_nacelle", color=gris)
        A.add(cq.Solid.makeCylinder(mo["helice_d"] / 2, 25, V(xs_ + mo["nacelle_l"] / 2 + 5, 0, z_nac), V(1, 0, 0)),
              name="moteur_helice", color=cq.Color(0.1, 0.1, 0.1))
        A.add(cq.Solid.makeBox(60, 70, 60, V(xs_ - 30 - mo["recul_arbre"] + 10, -35, ch["z_bride"] - 20)), name="moteur_bride", color=gris)
        k["_moteur"] = dict(helice_z=z_nac, bas_pale=z_nac - mo["helice_d"] / 2,
                            tete_haut=zsb + mo["arbre_l"] + mo["tete"][2], x_arbre=xs_)
    # pylônes au bout du coffre, sous chaque joue, au droit du mât
    py = k["pylones"]
    for nom, sg in (("babord", 1), ("tribord", -1)):
        z0 = interp_pont(m["x_pied"], sg * PONT_CFG["entraxe"] / 2) + 1
        x0, y0 = m["x_pied"] - py["dx"] / 2, (sg * (wi - py["dy"] / 2)) - py["dy"] / 2
        ztp = zb_at(abs(y0) if sg > 0 else abs(y0 + py["dy"])) 
        blk = cq.Solid.makeBox(py["dx"], py["dy"], ztp - z0, V(x0, y0, z0))
        t = py["ep"]
        blk = blk.cut(cq.Solid.makeBox(py["dx"] - 2 * t, py["dy"] - 2 * t, ztp - z0, V(x0 + t, y0 + t, z0)))
        A.add(blk, name=f"pylone_coffre_{nom}", color=bois)
    # bancs latéraux sur les longerons, entre le trampoline et la joue
    es, eb, el, r = b["ep_assise"], b["ep_fond"], b["ep_cotes"], b["rayon_aretes"]
    xb0 = b.get("x_debut", xa)
    L = xa + b["longueur"] - xb0
    for nom, sg in (("babord", 1), ("tribord", -1)):
        yi, yo = sg * b["y_int"], sg * wi
        y0, larg = min(yi, yo), abs(yo - yi)
        outer = (cq.Workplane("XY").box(L, larg, hb, centered=False).translate((xb0, y0, zt0))
                 .edges("|X and >Z").fillet(r))
        inner = cq.Workplane("XY").box(L - 2 * el, larg - 2 * el, hb - es - eb, centered=False).translate(
            (xb0 + el, y0 + el, zt0 + eb))
        cas = outer.cut(inner).val()
        if POUTRE_AV.get("degagement") is not None:
            cas = cas.cut(POUTRE_AV["degagement"])
        else:
            cas = cas.cut(cq.Solid.makeCylinder(b["encoche_poutre_r"], larg + 20, V(b["poutre_x"], y0 + larg + 10, b["poutre_z"]), V(0, -1, 0)))
        cas = cas.cut(cq.Solid.makeCylinder(b["encoche_longeron_r"], L + 20, V(xb0 - 10, sg * b["longeron_y"], b["poutre_z"]), V(1, 0, 0)))
        cut = cq.Solid.makeBox(L + 10, larg + 10, es + 50, V(xb0 - 5, y0 - 5, zs - es))
        A.add(cas.cut(cut), name=f"banc_{nom}_caisson", color=bois)
        A.add(cas.intersect(cut), name=f"banc_{nom}_assise", color=cq.Color(0.72, 0.50, 0.32))

CFG_MAT = {}
CFG_COFFRE_Y = {}
POUTRE_AV = {}

def poutre_cintree(x, z_ext, fleche, y_ext, r, n=24, y_lim=None):
    """Tube cintré (flèche parabolique vers le haut au milieu), axe à z_ext en y=±y_ext ; tracé de -y_lim à +y_lim."""
    yl = y_lim or y_ext
    pts = [V(x, y, z_ext + fleche * (1 - (y / y_ext) ** 2)) for y in [-yl + 2 * yl * i / n for i in range(n + 1)]]
    e = cq.Edge.makeSpline(pts)
    path = cq.Wire.assembleEdges([e])
    prof = cq.Wire.makeCircle(r, pts[0], e.tangentAt(0))
    return cq.Solid.sweep(prof, [], path, True, False)
PONT_CFG = {}
def interp_pont(x, y):
    """Dessus du pont (bombé) à (x, y), d'après les tables de coque."""
    c = PONT_CFG
    yc = c["entraxe"] / 2 * (1 if y > 0 else -1)
    b = interp(c["demi_largeur"], x); d = interp(c["pont"], x)
    t = min(1.0, abs(y - yc) / b)
    return d - c["bouge_pont"] + c["bouge_pont"] * math.sqrt(max(0.0, 1 - t * t))

def build(cfg):
    PONT_CFG.clear(); PONT_CFG.update(cfg["coques"])
    CFG_MAT.clear(); CFG_MAT.update(cfg["mats"])
    CFG_COFFRE_Y.clear()
    if "coffre" in cfg:
        CFG_COFFRE_Y["y_joue"] = cfg["coffre"]["largeur"] / 2
    c, p, m, vo, s = cfg["coques"], cfg["plateforme"], cfg["mats"], cfg["voile"], cfg["safrans"]
    hy = c["entraxe"] / 2
    fb, rb, bz = p["poutre_av_x"], p["poutre_ar_x"], p["poutre_z"]
    A = cq.Assembly(name="HC16_Rando_sans_coffre")
    gris, alu, noir = cq.Color(0.89, 0.88, 0.86), cq.Color(0.62, 0.64, 0.66), cq.Color(0.12, 0.12, 0.12)

    for nom, y in (("babord", hy), ("tribord", -hy)):
        A.add(coque(c, y), name=f"coque_{nom}", color=gris)
        for xb, tag in ((fb, "av"), (rb, "ar")):
            A.add(cyl((xb, y, interp(c["pont"], xb)), (xb, y, bz), p["pylone_diam"]),
                  name=f"pylone_{tag}_{nom}", color=alu)
        A.add(cyl((fb, y, bz), (rb, y, bz), p["longeron_diam"]), name=f"longeron_{nom}", color=alu)
        A.add(cq.Solid.makeBox(s["corde"], s["epaisseur"], s["hauteur"],
              V(s["x"] - s["corde"] / 2, y - s["epaisseur"] / 2, s["z_centre"] - s["hauteur"] / 2)),
              name=f"safran_{nom}", color=noir)
    lp = p["poutre_longueur"] / 2
    POUTRE_AV.clear()
    if p.get("poutre_av_fleche"):
        pav = poutre_cintree(fb, bz, p["poutre_av_fleche"], lp, p["poutre_diam"] / 2)
        POUTRE_AV.update(x=fb, z_ext=bz, fleche=p["poutre_av_fleche"], y_ext=lp, r=p["poutre_diam"] / 2,
                         degagement=poutre_cintree(fb, bz, p["poutre_av_fleche"], lp, p["poutre_diam"] / 2 + 4, y_lim=lp + 60))
        A.add(pav, name="poutre_av", color=alu)
    else:
        A.add(cyl((fb, -lp, bz), (fb, lp, bz), p["poutre_diam"]), name="poutre_av", color=alu)
    A.add(cyl((rb, -lp, bz), (rb, lp, bz), p["poutre_diam"]), name="poutre_ar", color=alu)
    A.add(cyl((s["barre_x"], -hy, s["barre_z"]), (s["barre_x"], hy, s["barre_z"]), 30),
          name="barre_accouplement", color=alu)
    A.add(cq.Solid.makeBox(rb - fb, 2 * hy, 3, V(fb, -hy, p["trampoline_z"] - 3)),
          name="trampoline", color=cq.Color(0.17, 0.17, 0.17))

    if "coffre" in cfg:
        coffre(A, cfg["coffre"])

    a = math.radians(m["quete_deg"])
    u = V(math.sin(a), 0, math.cos(a))
    enr = vo.get("enroulement", {})
    for nom, y in (("babord", m["y_axe"]), ("tribord", -m["y_axe"])):
        f = V(m["x_pied"], y, m["z_pied"])
        A.add(cq.Solid.makeCylinder(m["diam"] / 2, m["longueur"], f, u), name=f"mat_{nom}", color=noir)
        if "collier_hauteur" in m:
            tc = m["collier_hauteur"]; c0 = f + u * (tc - 25)
            col = cq.Solid.makeCylinder(46, 50, c0, u).cut(cq.Solid.makeCylinder(31, 50, c0, u))
            yj = CFG_COFFRE_Y.get("y_joue")                  # demi-collier (étrier) boulonné sur la joue
            if yj:
                sgn = 1 if y > 0 else -1
                col = col.cut(cq.Solid.makeBox(400, 400, 400, V(c0.x - 200, sgn * yj - (400 if sgn > 0 else 0), c0.z - 200)))
            A.add(col, name=f"collier_{nom}", color=cq.Color(0.55, 0.55, 0.58))
        h = f + u * m["haubanage"]
        A.add(cq.Solid.makeSphere(25, h, angleDegrees1=-90, angleDegrees2=90),
              name=f"repere_haubanage_{nom}", color=cq.Color(0.33, 0.29, 0.72))
        rest, d = voile_restante(vo["contour"], a, enr.get(nom, 0))
        if rest:
            pts = [(m["x_pied"] + dx, m["z_pied"] + dz) for dx, dz in rest]
            voile = cq.Workplane("XZ", origin=(0, y, 0)).polyline(pts).close().extrude(0.5, both=True)
            A.add(voile, name=f"voile_{nom}", color=cq.Color(0.95, 0.93, 0.88))
        lv = vo["livarde"]
        s0 = f + u * lv["w_mat"]
        cu, cw = vo["contour"][1]                                    # point d'écoute voile pleine
        s1 = f + V(cu * math.cos(a) + cw * math.sin(a), 0, -cu * math.sin(a) + cw * math.cos(a))
        for sg, cote in ((1, "a"), (-1, "b")):
            mid = s0 + (s1 - s0) * 0.45 + V(0, sg * lv["ecart"], 0)
            bez = [s0 * (1 - t) ** 2 + mid * (2 * t * (1 - t)) + s1 * t ** 2
                   for t in [i / 10 for i in range(11)]]
            seg = cq.Compound.makeCompound([cyl(q0.toTuple(), q1.toTuple(), lv["diam"])
                                            for q0, q1 in zip(bez, bez[1:])])
            A.add(seg, name=f"livarde_{nom}_{cote}", color=cq.Color(0.45, 0.45, 0.45))
    return A

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "cotes.yaml"
    out = sys.argv[2] if len(sys.argv) > 2 else "hc16_rando_sans_coffre.step"
    cfg = yaml.safe_load(open(src))
    A = build(cfg)
    m, vo = cfg["mats"], cfg["voile"]
    a = math.radians(m["quete_deg"])
    for nom in ("babord", "tribord"):
        f = vo.get("enroulement", {}).get(nom, 0)
        rest, d = voile_restante(vo["contour"], a, f)
        if rest:
            S, (cx, cz) = aire_cdg(rest)
            print(f"voile {nom} : enroulée {f:.0%} (largeur {d:.0f} mm), {S/1e6:.2f} m², "
                  f"CV {m['x_pied']+cx:.0f} mm de l'étrave, {m['z_pied']+cz:.0f} mm / flottaison")
        else:
            print(f"voile {nom} : entièrement roulée")
    A.export(out)
    print("OK", out)
